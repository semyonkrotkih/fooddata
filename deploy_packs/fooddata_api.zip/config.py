SQL_CONNECTION_STRING = (
    "Driver={ODBC Driver 18 for SQL Server};"
    "Server=tcp:fooddata.database.windows.net,1433;"
    "Database=Fooddata;"
    "UID=semyon;PWD={HappyDiver01;};"
    "TrustServerCertificate=yes;"
)
ANTHROPIC_API_KEY ="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"
